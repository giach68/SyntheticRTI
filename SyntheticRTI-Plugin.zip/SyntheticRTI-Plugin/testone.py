def ciao():
    print("lol")
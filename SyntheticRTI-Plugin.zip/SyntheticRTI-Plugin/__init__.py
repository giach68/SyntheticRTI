import bpy

from .testone import ciao

bl_info = {
    "name": "SyntheticRTI",
    "author": "Andrea Dall'Alba",
    "version": (0, 4, 0),
    "blender": (2, 79, 0),
    "location": "View3D > Tools > SyntheticRTI",
    "description": "Plugin to help creating the synthetic database for RTI",
    "category": "3D View",
}

print(srtifunc.format_index(15,4))
testone.ciao

def register():
    bpy.utils.register_module(__name__)

def unregister():
    bpy.utils.unregister_module(__name__)